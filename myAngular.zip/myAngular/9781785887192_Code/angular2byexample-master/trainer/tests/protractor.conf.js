exports.config = {
    specs: ['e2e/*.e2e.js'],
    baseUrl: 'http://localhost:9000/index.html',
    seleniumAddress: 'http://localhost:4444/wd/hub',
    useAllAngular2AppRoots: true
}
