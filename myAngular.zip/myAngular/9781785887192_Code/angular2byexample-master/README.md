# Angular2 By Example

[![Angular2 By Example Front Cover](https://d1ldz4te4covpm.cloudfront.net/sites/default/files/imagecache/ppv4_main_book_cover/B05079_MockupCover_Normal.jpg)](https://www.packtpub.com/web-development/angular-2-example)

Source code repository for the book [Angular2 by Example](https://www.packtpub.com/web-development/angular-2-example)

**Releasing soon!!**

To setup code for Guess The Number see the README.md in **guessthenumber** folder.

To setup code for Personal Trainer see the README.md in **trainer** folder.

## Note

The **master** branch contains the final outcome for both the samples we build throughout the book.

Chapter progress is tracked using individual branches. Each **chapter has checkpoints** and each checkpoint code is **available on a seperate branch**.

For example, branches *base*, *checkpoint2.1*, *checkpoint2.2*, *checkpoint2.3* and *checkpoint2.4* contain code checkpoints for **Chapter 2**.
